<?php

return [

    /*
    |--------------------------------------------------------------------------
    | Third Party Services
    |--------------------------------------------------------------------------
    |
    | This file is for storing the credentials for third party services such
    | as Mailgun, Postmark, AWS and more. This file provides the de facto
    | location for this type of information, allowing packages to have
    | a conventional file to locate the various service credentials.
    |
    */

    'postmark' => [
        'key' => env('POSTMARK_API_KEY'),
    ],

    'resend' => [
        'key' => env('RESEND_API_KEY'),
    ],

    'ses' => [
        'key' => env('AWS_ACCESS_KEY_ID'),
        'secret' => env('AWS_SECRET_ACCESS_KEY'),
        'region' => env('AWS_DEFAULT_REGION', 'us-east-1'),
    ],

    'slack' => [
        'notifications' => [
            'bot_user_oauth_token' => env('SLACK_BOT_USER_OAUTH_TOKEN'),
            'channel' => env('SLACK_BOT_USER_DEFAULT_CHANNEL'),
        ],
    ],

    'external_api' => [
        'url' => env('EXTERNAL_API_URL', 'https://dietdev-ledsvd8q.on-forge.com/api'),
        'token' => env('EXTERNAL_API_TOKEN'),
        /** When true (default), checkout OTP uses POST login/ordinary/reset + verify and stores API token in session. */
        'checkout_use_external_login' => filter_var(env('CHECKOUT_USE_EXTERNAL_LOGIN', true), FILTER_VALIDATE_BOOLEAN),
    ],

    'moyasar' => [
        'publishable_key' => env('MOYASAR_PUBLISHABLE_KEY'),
        'secret_key' => env('MOYASAR_SECRET_KEY'),
        'api_url' => env('MOYASAR_API_URL', 'https://api.moyasar.com/v1'),
    ],

    'google_maps' => [
        'key' => env('GOOGLE_MAPS_API_KEY', ''),
    ],

];
